
public class FloodIt extends java.lang.Object{

  public static void main(String[] args){

    GameView frame = new GameView();
  }



}
