public class RunS {
	public static void main(String[] Args){
		GameView frame = new GameView();
	}
}
