//import java.io.*;


public class temp {

public static void main(String[] args){
  System.out.println(temp.class.getResource("/data/S/ball-0.png"));
}
}


//public class File extends Object implements Serializable, Comparable<File>{

//}
